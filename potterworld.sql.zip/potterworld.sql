-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 01-Jan-2009 às 05:45
-- Versão do servidor: 10.1.30-MariaDB
-- PHP Version: 7.2.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `potterworld`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `escolas`
--

CREATE TABLE `escolas` (
  `idEscola` int(10) UNSIGNED NOT NULL,
  `nomeEscola` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `escolas`
--

TRUNCATE TABLE `escolas`;
--
-- Extraindo dados da tabela `escolas`
--

INSERT INTO `escolas` (`idEscola`, `nomeEscola`) VALUES
(1, 'Nenhuma'),
(2, 'Hogwarts');

-- --------------------------------------------------------

--
-- Estrutura da tabela `familias`
--

CREATE TABLE `familias` (
  `idFamilia` int(11) NOT NULL,
  `nomeFamilia` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `descFamiliia` text COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Truncate table before insert `familias`
--

TRUNCATE TABLE `familias`;
--
-- Extraindo dados da tabela `familias`
--

INSERT INTO `familias` (`idFamilia`, `nomeFamilia`, `descFamiliia`) VALUES
(1, 'Nenhuma', '');

-- --------------------------------------------------------

--
-- Estrutura da tabela `logtentativa`
--

CREATE TABLE `logtentativa` (
  `id` int(11) NOT NULL,
  `ip` varchar(15) COLLATE latin1_general_ci DEFAULT NULL,
  `login` varchar(60) COLLATE latin1_general_ci NOT NULL,
  `senha` varchar(300) COLLATE latin1_general_ci DEFAULT NULL,
  `origem` varchar(300) COLLATE latin1_general_ci DEFAULT NULL,
  `bloqueado` char(3) COLLATE latin1_general_ci DEFAULT NULL,
  `data_hora` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Truncate table before insert `logtentativa`
--

TRUNCATE TABLE `logtentativa`;
--
-- Extraindo dados da tabela `logtentativa`
--

INSERT INTO `logtentativa` (`id`, `ip`, `login`, `senha`, `origem`, `bloqueado`, `data_hora`) VALUES
(18, '::1', 'ffd', 'fdf', 'http://localhost/loginphp/login.php', 'NAO', '2018-03-10 07:55:45'),
(19, '::1', 'gg', 'gfgf', 'http://localhost/loginphp/login.php', 'NAO', '2018-03-10 08:25:10'),
(20, '::1', 'gg', 'dff', 'http://localhost/loginphp/login.php', 'NAO', '2018-03-10 09:10:12'),
(21, '::1', 'fdd', 'fdd', 'http://localhost/loginphp/login.php', 'NAO', '2018-03-10 09:10:37');

-- --------------------------------------------------------

--
-- Estrutura da tabela `personagem`
--

CREATE TABLE `personagem` (
  `idPersonagem` int(10) UNSIGNED ZEROFILL NOT NULL,
  `nomePersonagem` varchar(60) COLLATE latin1_general_ci NOT NULL,
  `descPersonagem` text COLLATE latin1_general_ci NOT NULL,
  `idFamilia` int(11) DEFAULT '1',
  `idUsuario` int(11) NOT NULL,
  `idProfissao` int(11) DEFAULT NULL,
  `idEscola` int(11) NOT NULL DEFAULT '1',
  `idade` int(3) NOT NULL DEFAULT '0',
  `HP` int(6) NOT NULL DEFAULT '100',
  `MP` int(6) NOT NULL DEFAULT '100',
  `graduacao` enum('Primeiro Ano','Segundo Ano','Terceiro Ano','Quarto Ano','Quinto Ano','Sexto Ano','Sétimo Ano','Formado','Não ingressou') CHARACTER SET utf8 NOT NULL DEFAULT 'Não ingressou',
  `sangue` enum('Sangue Puro','Mestiço','Nascido Trouxa','Aborto','Trouxa') CHARACTER SET utf8 NOT NULL DEFAULT 'Mestiço',
  `idPai` int(11) DEFAULT '1',
  `idMae` int(11) DEFAULT '1',
  `tipo` char(1) CHARACTER SET utf8 NOT NULL DEFAULT 'E',
  `criado` datetime NOT NULL,
  `avatar` varchar(120) COLLATE latin1_general_ci NOT NULL,
  `ultimoPost` datetime NOT NULL,
  `galeoes` int(11) NOT NULL DEFAULT '0',
  `sicles` int(11) NOT NULL DEFAULT '0',
  `nuques` int(11) NOT NULL DEFAULT '0',
  `ultimoLogin` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Truncate table before insert `personagem`
--

TRUNCATE TABLE `personagem`;
--
-- Extraindo dados da tabela `personagem`
--

INSERT INTO `personagem` (`idPersonagem`, `nomePersonagem`, `descPersonagem`, `idFamilia`, `idUsuario`, `idProfissao`, `idEscola`, `idade`, `HP`, `MP`, `graduacao`, `sangue`, `idPai`, `idMae`, `tipo`, `criado`, `avatar`, `ultimoPost`, `galeoes`, `sicles`, `nuques`, `ultimoLogin`) VALUES
(0000000001, 'nenhum', '', NULL, 1, NULL, 1, 0, 100, 100, 'Não ingressou', 'Mestiço', NULL, NULL, 'S', '2018-03-01 17:46:42', '', '0000-00-00 00:00:00', 0, 0, 0, '0000-00-00 00:00:00'),
(0000000002, 'Raffael McDonald', '<b>Lôrem ipsum</b> dôlor sit ámet, agám nónumy póstêà nõ duô, te iisqué môlêstie séd, minim ínímicus éx sit? Vis níbh inermis ãdipisçing éu, át êverti dólorum çum! Ex çômmune constitutõ mel, vide tritáni accusamus eu mêà, àccusam méntitum réfêrrêntur vis at! Cum ne çàse utinám sçriptà, sãle perpetuá périçulis per at, ín duo idquê necessitátibus. Ex verõ nonumes nâm.\r\n\r\nEst mâlís múcius cu. Oratío lêgêndõs has te, àccusãmus disputãndo eàm te. An diçtãs feugiat admodum pro? Quidám minímum maiestátís vim ex! Alii elitr percipit sed ne, eu quodsi méntitúm vim?\r\n\r\nLiber dõctus pro ne, modó diçtà sadípscing çu vis. Êx zril deçorê vis, ét qúi âliquip facilisi! Sêã ut níbh fâcéte, át labitúr refórmidans eum? Usú dóming fáçilisi àd. Exerçi veritús nô usu, nàm everti diçeret éu.\r\n\r\nIn fugit theôphrastus mél, quándo philosophiã éôs ad! Désêruisse disputàtioni mei ex, epicuri éléifend theophràstús ad eâm, eirmôd delicatâ scribêntur at mea? Lâborês iudicábít sâdipsçing út prõ, fàcete everti récteque in eum, vel íd albucius appêtere intellegat. Vel àn libris quáêstíó, éx vôluptàtúm theôphrãstus sit. Eá sêd làbore quodsi referrêntur. Habeô nêmore ét néc, facêr prompta vis êt.\r\n\r\nPri tâtion dicunt sensibus no, meà harum déséruisse cu? In seá ómnis âlíquid suscipit, mei mális dicit vituperãtóribus in. Tántás ímpedit officiis êí eum, quód ubique noster mei et. Ãliquíp blandit prõdesset ãn seã, hãs né omnes dissentiâs!\r\n\r\nSéâ purto wisi ét. Láoreet àtômórum neglegêntur mêâ tê, duo fàcêr iusto cómplectitur at, ea éos tantás scribentúr. Vél át quod môderatius, cõmmôdõ délectus intellegat no duõ. Fáçete âtõmorum cônclusíónémque vim et, erãt perfêctó qúo cú.\r\n\r\nÉst ea alií clita muneré, id áççumsan põnderum adipiscing vis. In corpóra omittam côncludáturque víx, falli çópiósae qúaestio ut sed? Mei ínsõlens pértinãcia cu, libér scripserit nec at. Ôdio suás definitiones vis eu. His id çàusâe deterruisset, sonet vívendo quo éú, doloré legêndos nô quô?\r\n\r\nAt nónumy íntérprêtaris eám, eu eàm mazim aeterno postulant? Nõ abhorreant posidonium vix. Vel ígnótà altêra inçídêrint at, hâs in nihil placérat detràxit. Hãrum oçúrreret in mel! Ludus invidunt êu vêl?\r\n\r\nViris omnesquê nam ut. Vix zríl persecúti út, eám modus utãmur ãbhórrêânt cu. Munere vôluptaria ârgumentum ea sêd, côrpõrà blàndit communê et sit. Tê cúm modus pâulo ãudire, sêã êa ignótã põstulant vituperatõribus.\r\n\r\nVirtute pârtiéndô ne hâs, eí bonôrum delectus hís, nãm talé dêsêruisse ât. Nam duis mélioré suscipíàntur id, illum ánimal iudícabit id pér. Ius putént evérti id, in mêi dícam pêrsecúti interpretaris, id his quas elitr refêrrentur! Àssum suàvitâte ócurrêrêt ius éx, fãbulas tibiquê desêruisse mei te?\r\n\r\nNam tàtíón lâbóre çommuné ut, vim tê çonstitutó posidonium, ei illud díctãs platonem vel. Per chóro óptión nõstrum eá, usu intégre nómínàti éà, mel augue dicànt luptatum ãt. Ei duo àudiam melióre volutpàt, ãd tále solum animal nám. Pro ad àçcusamús lábôràmús? Per mâlorum salutãndi consectetuer eu, dolor susçípit sàlutatus in mel. Ut qui sólet erroribus efficiendi.\r\n\r\nEum nô fêrri dóçendi. Ut vírtuté màiestatis quí. No sit sãepê numquam medíocrem, primis cónclusionemqúé nô pro, eos qúodsi prôpriae êa. Sit ãd quod dolõrum, út séa vócênt delenit éleifend! Méà zril omnésqúê te, eâ vis sápêret praesênt qualisquê? Sit ân témpor íncõrrúpté, duõ fêugiât mêntitum platõnem êi.\r\n\r\nNe stet ferri éverti çum? Cu êlaborarêt intellêgam vim, nibh nullá sed ut. Cum ut sôlet menandri, facête hábemus noluisse án nãm, tatíon scriptõrem ei vix. Aliá eripúít his ãt. Et lorem sàlutàtus neglêgentur sêd? Vírtutê sapéret vix ne, lábõre feugait àccumsan duo éã. Ius ea dêçore denique prõbatus.\r\n\r\nUllum õption in pri, qui prômptà bonorum ex, vís véro utinãm necéssitátíbus in. Feugiát apparéât usu ei, ut vís reque málís lúcilius. Mel solet audiâm veritus an? Erípuit legimus sit éu, án nám tálé suás lúptatum. Éx salutándí iràcundíâ disputandô seà? Eam ridéns ôfficiis qúálísqúê át.\r\n\r\nPàrtem môderatius séd éi, id mêi quém illum putent. Ômniúm corpora éos ad, etiãm vidissé ád cum. Nisl sénsibus ut qúi, êu õratió virtuté eam? At stét signifêrúmque sit, vel debêt récteque ei? Dictã dólôrem eu sit, çum éi útãmur definiebas, ét dóming mediõcrem mêi.\r\n\r\nIn per vide êpicureí oporteat. Quód paúlô similiqúe seá nô, his ãn tàle áudiâm ânçillaé. Àperíam rectéqúe sadipscing mêã ín, âd meis utroqué glóriátur séá, ius id sonêt délicãtã deterruissêt. Cu sumó saperét rectêque eúm. Éa hàrum ornàtús definiebas séà, ne pertínax persequeris seâ.\r\n\r\nAt mãgna dolore cópiosàê nâm? Ius no páulô soluta mnesárchum, vôlumús mínimum êligêndi in per, tê usu réquê chorô theôphrastus. Convénirê êxplicari út has. Êx autem ánimal tibiquê nãm, id erós fácete fàcilisis vis, nô quodsi labitur mâiestátis vim. Vitáe çoncéptám signiférúmqúe pri út.\r\n\r\nSôlét tamqúãm ponderum mel no, álbucius susçípít prí an. Dicõ tota nóstrõ et est. Cum àççumsàn omnêsque delicatíssími nô? Agám sôlum çõnstitúto méi cu, usu ut inani cônclusíónêmquê.\r\n\r\nMeís témpõr póstea has eã, útámúr hàbémus êós êt? An insoléns perçipitur sêa, utrõquê ãtómôrum ât vél. Option tinçidunt efficiãntur id nám, pertinâx eleifend díssentiàs quí ãt, choro eirmõd íús eí! Meis maiórum qui éx, et êum íllud idque dóming. Ôbliquê póndérum eu est? Né nâm quem átqúi, per altérum fâcilis dissentiet te?\r\n\r\nÉa úsu elabóraret cónséqúuntur. Eum çú mundi orãtío ópôrtére, te nec ófficíis âccommõdarê, ut eos évêrtí torquàtós. Eàm út tãle appeterê elàbóráret, étiam ãbhõrreánt êãm te. Mel plâcêrat efficiántur et, eos in úbique êuripidis assueverit, seã unum nullà veníam ãt. Summó eripuit glóriatur prô id, sed te agám dôlorém, eú qúi iudicó munere aliénum? Hábeo adipisçíng àrgúmentum an êõs, ei opôrteát quaéstiõ sit?\r\n\r\nAd prí làudem laórêet conçlusionemque, ex véréár aliqúandó çõnstitútô êam, nõ módó nâtum appâreat quó. Víx ex grãêce fãcête constituto. Éi nullam deléníti mnêsarchúm eum. Nullâ dicit ei neç, pro éu ludus iísqúe cômprehensàm! Êx ést dictãs oçurreret vulputãte!\r\n\r\nUtinàm nõnumy omnésque ut êam, id quo súmo pópúlo âcçumsàn, et úsú elitr numquàm plãcerát! Ad hãs elít iúdícó diçant, út sed sint pertinácia. Sed té purto fabéllás. Éum cu alií rídens. Eà vide vocênt âdipisçi qui. Ut qui fácér tãmquám phílósóphiá.\r\n\r\nId melióre delicatà deseruissé pri. Êst causãe percipit adoléscens né? Véri ímpêrdiet râtíonibus cu quo, nobis utinám ân vis. Múnere nostrúm ex vim, his nullàm vivendúm nô erãnt.', NULL, 2, NULL, 1, 10, 100, 100, 'Não ingressou', 'Mestiço', 1, 1, 'E', '2018-03-01 17:56:24', 'lorempixel.com/200/320/people/', '0000-00-00 00:00:00', 1, 10, 10, '2018-03-03 03:31:53'),
(0000000003, 'John Rathbone McDonald', 'fdsgdsgg', NULL, 2, NULL, 2, 25, 1000, 1000, 'Formado', 'Sangue Puro', 1, 1, 'A', '2018-03-02 02:46:41', '78.media.tumblr.com/402188e3f31e602cb6e747490fbd68fd/tumblr_n0omk1kVks1r1jjf2o1_500.png', '0000-00-00 00:00:00', 1015, 12, 7, '2018-03-03 03:32:00');

-- --------------------------------------------------------

--
-- Estrutura da tabela `photoplayers`
--

CREATE TABLE `photoplayers` (
  `idPP` int(11) NOT NULL,
  `nomePP` varchar(30) COLLATE latin1_general_ci NOT NULL,
  `idPersonagem` int(11) NOT NULL,
  `Situação` enum('Regular','Irregular','Aguardando Aprovação') COLLATE latin1_general_ci NOT NULL,
  `Sexo` enum('Masculino','Femenino','','') COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Truncate table before insert `photoplayers`
--

TRUNCATE TABLE `photoplayers`;
-- --------------------------------------------------------

--
-- Estrutura da tabela `usuarios`
--

CREATE TABLE `usuarios` (
  `idUsuario` int(10) UNSIGNED ZEROFILL NOT NULL,
  `login` varchar(256) COLLATE latin1_general_ci NOT NULL,
  `senha` varchar(256) COLLATE latin1_general_ci NOT NULL,
  `email` varchar(256) COLLATE latin1_general_ci NOT NULL,
  `premium` tinyint(1) NOT NULL DEFAULT '0',
  `cPersonagemA` tinyint(1) NOT NULL DEFAULT '1',
  `cPersonagemC` tinyint(1) NOT NULL DEFAULT '1',
  `nome` varchar(60) COLLATE latin1_general_ci NOT NULL,
  `dtNascimento` date NOT NULL,
  `status` char(1) COLLATE latin1_general_ci NOT NULL DEFAULT 'A',
  `termos` tinyint(1) NOT NULL,
  `dadosValidos` tinyint(1) NOT NULL,
  `newslater` tinyint(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Truncate table before insert `usuarios`
--

TRUNCATE TABLE `usuarios`;
--
-- Extraindo dados da tabela `usuarios`
--

INSERT INTO `usuarios` (`idUsuario`, `login`, `senha`, `email`, `premium`, `cPersonagemA`, `cPersonagemC`, `nome`, `dtNascimento`, `status`, `termos`, `dadosValidos`, `newslater`) VALUES
(0000000001, 'sistema', 'Potterworld', 'potterworld@mail.com', 0, 1, 1, '', '0000-00-00', '', 0, 0, 0),
(0000000002, 'raffasarts', '123', '', 0, 1, 1, '', '0000-00-00', '', 0, 0, 0),
(0000000003, 'teste', 'sdsdd', 'rada@fdfd.com', 0, 1, 1, 'rrtrtr', '2018-03-09', 'a', 1, 1, 0),
(0000000004, 'Rafaeldemendonca', '$2y$10$mDiAVLz1RtQs/6Q4JeJoiOSwHYpYbsMqnzmOXCRq17qYxbuem/kOO', 'dff@dsd.com', 0, 1, 1, 'Rafael de Mendonça', '1994-08-29', '', 1, 1, 1),
(0000000005, 'raffasarts29', '$2y$10$bgg9y5R6OJKgj3MCmR0cKu1NCmi86W03Ug..ttRAjj/lcyKpRz4lC', 'raffasarts@gmail.com', 0, 1, 1, 'Rafael de Mendonça Araújo', '1994-08-29', 'A', 1, 1, 0),
(0000000009, 'raffasarts', '$2y$10$RegX1T3AF04PNuVmBPNHB.iB9xMzRqm3QmHzA/VWVKkfb8u/NuYcm', 'rada@fdfd.com', 0, 1, 1, 'rre fff', '1994-08-29', 'A', 1, 1, 0),
(0000000010, 'joaodasilva', '$2y$10$CbZNX23acn37V8uAnkT2Fu2qObCvj1VRtOBa5Snp/r6V8JPNf0h2G', 'joao@bezerra.dasilva.com', 0, 1, 1, 'João da Silva', '1915-12-25', 'A', 1, 1, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `escolas`
--
ALTER TABLE `escolas`
  ADD PRIMARY KEY (`idEscola`);

--
-- Indexes for table `familias`
--
ALTER TABLE `familias`
  ADD PRIMARY KEY (`idFamilia`),
  ADD UNIQUE KEY `nomeFamilia` (`nomeFamilia`);

--
-- Indexes for table `logtentativa`
--
ALTER TABLE `logtentativa`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `personagem`
--
ALTER TABLE `personagem`
  ADD PRIMARY KEY (`idPersonagem`),
  ADD UNIQUE KEY `nomePersonagem` (`nomePersonagem`),
  ADD KEY `idUsuario` (`idUsuario`),
  ADD KEY `idEscola` (`idEscola`);

--
-- Indexes for table `photoplayers`
--
ALTER TABLE `photoplayers`
  ADD PRIMARY KEY (`idPP`),
  ADD UNIQUE KEY `idPersonagem` (`idPersonagem`),
  ADD UNIQUE KEY `nomePP` (`nomePP`);

--
-- Indexes for table `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`idUsuario`),
  ADD UNIQUE KEY `login` (`login`,`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `escolas`
--
ALTER TABLE `escolas`
  MODIFY `idEscola` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `familias`
--
ALTER TABLE `familias`
  MODIFY `idFamilia` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `logtentativa`
--
ALTER TABLE `logtentativa`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `personagem`
--
ALTER TABLE `personagem`
  MODIFY `idPersonagem` int(10) UNSIGNED ZEROFILL NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `idUsuario` int(10) UNSIGNED ZEROFILL NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
